const usePurchaseOrderHelpers = () => {
	const createEmptyPurchaseRow = () => ({
		id: crypto.randomUUID(),
		code: '',
		desc: '',
		qty: '',
		uom: '',
		rate: '',
		disc: '',
		tax: '',
		batchItems: [createEmptyBatchRow()],
	});

	const createEmptyBatchRow = () => ({
		id: crypto.randomUUID(),
		color: '',
		doorType: '',
		seatType: '',
		quantity: '',
		uom: '',
		rate: '',
	});

	const createEmptyExpenseRow = () => ({
		id: crypto.randomUUID(),
		particular: '',
		amount: '',
		tax: 0,
	});

	return {
		createEmptyBatchRow,
		createEmptyExpenseRow,
		createEmptyPurchaseRow,
	};
};

export default usePurchaseOrderHelpers;
