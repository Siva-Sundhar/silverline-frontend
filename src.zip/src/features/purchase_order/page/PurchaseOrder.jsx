import { useRef, useState } from 'react';
import { formatGenericDate, toISODate } from '../../../utils/FormatGenericDate';
import PurchaseOrderHeader from '../components/PurchaseOrderHeader';
import PurchaseOrderItemTable from '../components/PurchaseOrderItemTable';

const PurchaseOrder = () => {
	// ? /================ Form Data ==================/ ? //
	const [formData, setFormData] = useState({
		voucherNo: '',
		voucherType: 'Purchase Order',
		suplierName: '',
		distributorName: '',
		voucherDate: toISODate(new Date()),
		orderNo: '',
		referenceDate: '',
		narration: '',
		createdBy: '',
		approvedBy: '',
		voucherStatus: '',
		tallyStatus: '',
		paymentStatus: '',
		taxMode: 'vat',
		taxType: 'inter',
		autoRound: true,
		totalAmount: '',
		totalQty: '',
		units: '',
	});

	// ? /================ Refs ==================/ ? //
	const headerRefs = useRef([]);
	const hiddenDateRef = useRef(null);
	const gridRefs = useRef({});
	const expenseRefs = useRef({});
	const remarksRef = useRef(null);
	const createdByRef = useRef(null);
	const distInfoRef = useRef(null);
	const suppInfoRef = useRef(null);
	const bottomRef = useRef(null);

	const [dateInputText, setDateInputText] = useState(
		formatGenericDate(new Date(), 'DD-MMM-YY'),
	);

    // ? /================ Set Header Refs ==================/ ? //
	const registerHeaderRef = (index) => (element) => {
		headerRefs.current[index] = element;
	};


    // ? /================ Date Sertter & Converter ==================/ ? //
	const commitDateChange = (rawText, field) => {
		const formattedDate = formatGenericDate(rawText, 'DD-MMM-YY');

		if (!formattedDate) {
			if (field === 'voucherDate') {
				setDateInputText(
					formData.voucherDate
						? formatGenericDate(formData.voucherDate, 'DD-MMM-YY')
						: '',
				);
			}

			// if (field === 'referenceDate') {
			// 	setRefDateInputText(
			// 		formData.referenceDate
			// 			? formatGenericDate(formData.referenceDate, 'DD-MMM-YY')
			// 			: '',
			// 	);
			// }

			return;
		}

		const isoDate = toISODate(rawText);

		setFormData((previous) => ({
			...previous,
			[field]: isoDate,
		}));

		if (field === 'voucherDate') {
			setDateInputText(formattedDate);
		}

		// if (field === 'referenceDate') {
		// 	setRefDateInputText(formattedDate);
		// }
	};

    // ? /================ Setter for Header ==================/ ? //
    const setField = (name) => (event) => {
		setFormData((previous) => ({
			...previous,
			[name]: event.target.value,
		}));
	};
	return (
		<div className="h-dvh w-full overflow-hidden bg-slate-200 p-1 box-border">
			<div className="flex h-full min-h-0 w-full flex-col overflow-hidden rounded border border-black bg-white shadow-md">
				<PurchaseOrderHeader
					formData={formData}
					commitDateChange={commitDateChange}
					registerHeaderRef={registerHeaderRef}
					isAlterMode={''}
					setField={setField}
					hiddenDateRef={hiddenDateRef}
					distInfoRef={distInfoRef}
					suppInfoRef={suppInfoRef}
                    setDateInputText={setDateInputText}
                    dateInputText={dateInputText}
				/>
				<main className="custom-scrollbar flex min-h-0 flex-1 flex-col overflow-auto relative">
					{/* <PurchaseOrderItemTable
						items={purchaseItem}
						totals={totals}
						open={open}
						setOpen={setOpen}
						gridRefs={gridRefs}
						
					/> */}
				</main>
			</div>
		</div>
	);
};
export default PurchaseOrder;
