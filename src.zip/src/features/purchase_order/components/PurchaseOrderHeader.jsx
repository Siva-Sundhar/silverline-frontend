import { Calendar, Eye } from 'lucide-react';                 


const headerInput =
	'h-5 border border-amber-300 bg-[#fee8af] px-1 text-slate-900 outline-none focus:border-blue-500 focus:bg-white';

const PurchaseOrderHeader = ({
	formData,
	isAlterMode,
	registerHeaderRef,
  headerRefs,
	setField,
	handleInvoicePreview,
	handleHeaderKeyDown,
	setCustomerInfo,
  commitDateChange,
  distInfoRef,
  suppInfoRef,
  hiddenDateRef,
  setSupplierInfo,
  dateInputText,
  setDateInputText
}) => {

  
	return (
		<header className="shrink-0 border-b border-slate-300 px-2 py-1 text-[13px]">
			<div className="flex flex-wrap items-center gap-x-4 gap-y-1">
				<div className="flex items-center gap-1">
					<label
						htmlFor="voucherNo"
						className="rounded-xs bg-blue-800 text-center text-[12px] font-bold uppercase text-white w-32"
					>
						{isAlterMode ? 'Purchase Order' : 'Purchase Order'}
					</label>
					<span className="ml-1 font-semibold text-slate-700 w-6">No</span>
					:
					<input
						// ref={(el) => (headerRefs.current[0] = el)}
						id="voucherNo"
						type="text"
						autoComplete="off"
						value={formData.voucherNo}
						readOnly
						className={`${headerInput} w-28 sm:w-36`}
					/>
				</div>

				<div className="flex items-center gap-2">
					<label
						htmlFor="orderNo"
						className="font-semibold text-slate-700 whitespace-nowrap w-16"
					>
						Order No
					</label>
					:
					<input
						ref={registerHeaderRef(1)}
						id="orderNo"
						value={formData.orderNo}
						onChange={setField('orderNo')}
						onKeyDown={(e) => handleHeaderKeyDown(e, headerRefs.current[2])}
						onMouseDown={(e) => {
							const input = e.currentTarget;

							if (document.activeElement !== input) {
								setTimeout(() => input.select(), 0);
							}
						}}
						className={`${headerInput} w-36 `}
					/>
				</div>

				{/* <div className="flex items-center gap-2">
                  <label
                    htmlFor="referenceDate"
                    className="font-semibold text-slate-700 whitespace-nowrap w-20"
                  >
                    Invoice Date
                  </label>
                  :
                  <input
                    ref={(el) => (headerRefs.current[2] = el)}
                    id="referenceDate"
                    value={refDateInputText}
                    onChange={(e) => setRefDateInputText(e.target.value)}
                    onBlur={() =>
                      commitDateChange(refDateInputText, 'referenceDate')
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
   
                        const ref = gridRefs.current['0-0'];
   
                        ref?.focus();
   
                        requestAnimationFrame(() => {
                          ref?.input?.select();
                        });
                      }
                    }}
                    onMouseDown={(e) => {
                      const input = e.currentTarget;
   
                      if (document.activeElement !== input) {
                        setTimeout(() => input.select(), 0);
                      }
                    }}
                    className={`${headerInput} w-20 text-right`}
                  />
                </div> */}

				<button
					type="button"
					// disabled=}
					onClick={handleInvoicePreview}
					className="flex h-5 items-center gap-1 rounded border border-blue-400 bg-blue-50 px-2 font-semibold text-blue-800 outline-none hover:border-blue-600 hover:bg-blue-100 focus-visible:ring-0 focus-visible:ring-blue-400 disabled:cursor-not-allowed disabled:opacity-50"
				>
					<Eye size={12} />
					Preview
				</button>

				{/* <PurchasePrint
					data={{ formData, purchaseItem, expenses }}
					isOpen={showPreview}
					onClose={() => setShowPreview(false)}
				/> */}

				<div className="flex items-center gap-1 sm:ml-auto">
					<label htmlFor="voucherDate" className="font-semibold text-slate-700">
						Date
					</label>
					:
					<input
						ref={registerHeaderRef(0)}
						id="voucherDate"
						type="text"
						value={dateInputText}
						onChange={(e) => setDateInputText(e.target.value)}
						onBlur={() => commitDateChange(dateInputText, 'voucherDate')}
						onKeyDown={(e) => handleHeaderKeyDown(e, headerRefs.current[1])}
						onMouseDown={(e) => {
							const input = e.currentTarget;

							if (document.activeElement !== input) {
								setTimeout(() => input.select(), 0);
							}
						}}
						className={`${headerInput} w-22 text-right`}
					/>
					<button
						type="button"
						tabIndex={-1}
						onClick={() => hiddenDateRef.current?.showPicker?.()}
						className="text-slate-700 outline-none hover:text-black"
						aria-label="Open date picker"
					>
						<Calendar size={18} />
					</button>
					<input
						ref={hiddenDateRef}
						type="date"
						value={formData.voucherDate}
						onChange={(e) => commitDateChange(e.target.value, 'voucherDate')}
						className="pointer-events-none absolute sr-only"
					/>
				</div>
			</div>

			<div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
				<div className="flex items-center gap-1 ">
					<label
						htmlFor="distributorName"
						className="font-semibold text-slate-700 whitespace-nowrap w-40"
					>
						Distributer Name
					</label>
					:
					<input
						ref={registerHeaderRef()}
						id="distributorName"
						type="text"
						autoComplete="off"
						value={formData.distributorName}
						onChange={setField('distributorName')}
						onKeyDown={(e) => {
							if (e.key === 'Enter') {
								e.preventDefault();

								const ref = distInfoRef.current;

								ref?.focus();

								requestAnimationFrame(() => {
									ref?.input?.select();
								});
								setCustomerInfo(true);
							}
						}}
						onMouseDown={(e) => {
							const input = e.currentTarget;

							if (document.activeElement !== input) {
								setTimeout(() => input.select(), 0);
							}
						}}
						// readOnly
						className={`${headerInput} w-96.5 `}
					/>
					{/* <GenericSelect
                    ref={(el) => (headerRefs.current[2] = el)}
                    options={customerOptions}
                    placeholder="Select Supplier..."
                    title="Suppliers "
                    value={
                      customerOptions.find(
                        (option) =>
                          String(option.value) === String(formData.customerName),
                      ) || null
                    }
                    onKeyDown={(e) =>
                      handleHeaderKeyDown(e, gridRefs.current['0-0'])
                    }
                    onChange={(selectedOption) => {
                      if (!selectedOption) {
                        return;
                      }
   
                      console.log(selectedOption);
   
                      setFormData((prev) => ({
                        ...prev,
                        customerName: selectedOption.label,
                      }));
                    }}
                    onSelect={(selectedOption) => {
                      if (selectedOption?.isEndOfList) {
                        return;
                      }
   
                      setTimeout(() => {
                        gridRefs.current['0-0'];
                        // expenseRefs.current[`${0}-particular`]?.select();
                      }, 0);
                    }}
                    labelKey="label"
                    valueKey="value"
                    inputFocusStyle={{
                      border: '1px solid #3B63EB',
                    }}
                    inputStyle={{
                      padding: '0 4px',
                      height: '20px',
                      width: '386px',
                      border: '1px solid #FCD34D',
                      backgroundColor: '#fee8af',
                    }}
                    menuStyle={{
                      width: '250px',
                      maxWidth: 'calc(100vw - 8px)',
                      right: '4px',
                      bottom: '4px',
                      top: '4px',
                    }}
                    optionStyle={{
                      padding: ' 0.5px 4px',
                    }}
   
                    // renderOption={renderProductOption}
                  /> */}
				</div>
				{/* <div className="flex  flex-1 items-center ">
                  <label
                    htmlFor="Tax Mode"
                    className="font-semibold text-slate-700 whitespace-nowrap "
                  >
                    
                  </label>
                  
                  <input
                    disabled
                    id="taxmode"
                    type="text"
                    autoComplete="off"
                    value={formData.taxMode.toUpperCase()}
                    className={`${headerInput} w-20 bg-slate-100 border-slate-100 cursor-not-allowed`}
                    onMouseDown={(e) => {
                      const input = e.currentTarget;
   
                      if (document.activeElement !== input) {
                        setTimeout(() => input.select(), 0);
                      }
                    }}
                  />
                </div> */}

				{/* {formData.voucherDate && (
                  <span className="ml-1 text-xs font-bold text-blue-800">
                    {getDayName(formData.voucherDate)}
                  </span>
                )} */}

				<div className="flex items-center gap-1 ml-auto">
					<label
						htmlFor="suplierName"
						className="font-semibold text-slate-700 whitespace-nowrap w-30"
					>
						Supplier Name
					</label>
					:
					<input
						ref={registerHeaderRef}
						id="suplierName"
						type="text"
						autoComplete="off"
						value={formData.suplierName}
						onChange={setField('suplierName')}
						onKeyDown={(e) => {
							if (e.key === 'Enter') {
								e.preventDefault();

								const ref = suppInfoRef.current;

								ref?.focus();

								requestAnimationFrame(() => {
									ref?.input?.select();
								});
								setSupplierInfo(true);
							}
						}}
						onMouseDown={(e) => {
							const input = e.currentTarget;

							if (document.activeElement !== input) {
								setTimeout(() => input.select(), 0);
							}
						}}
						// readOnly
						className={`${headerInput} w-96.5 `}
					/>
				</div>
			</div>
		</header>
	);
};

export default PurchaseOrderHeader;
